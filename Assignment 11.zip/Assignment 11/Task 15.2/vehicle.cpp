/*
    Author : Abdelrhman El Kheshen
    Date : 28 / 10 / 2025
    Details : Source file for class Vehicle
*/
/*#include "vehicle.hpp"
#include <iostream>

Vehicle::Vehicle(IStrategy* strategy)
                                    : strategy_{strategy}
{
    std::cout << "Object was created in Vehicle constructor.\n";
}

void Vehicle::vehicleSpeed()
{
    this->strategy_->CalculateSpeed();
}

Vehicle::~Vehicle()
{
    std::cout << "Object was destroyed in Vehicle destructor.\n";
}*/


